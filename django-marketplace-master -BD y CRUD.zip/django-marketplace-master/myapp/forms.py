from django import forms
from django.forms import ModelForm
from .models import Cliente, TipoTarjeta, Tarjeta

class ClienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = ['nombre', 'genero', 'fecha_nacimiento', 'clave', 'correo', 'es_miembro']
        widgets = {
            'fecha_nacimiento': forms.DateInput(attrs={'type': 'date'}),
            'correo': forms.EmailInput(attrs={'placeholder': 'Correo Electrónico'}),

        }

class TipoTarjetaForm(forms.ModelForm):
    class Meta:
        model = TipoTarjeta
        fields = ['id_tipo', 'descripcion']


class TarjetaForm(forms.ModelForm):
    class Meta:
        model = Tarjeta
        fields = ['numero_tarjeta', 'cvv', 'tipo', 'cliente']
        widgets = {
            'numero_tarjeta': forms.TextInput(attrs={'placeholder': 'Número de Tarjeta'}),
            'cvv': forms.TextInput(attrs={'placeholder': 'CVV'}),
        }
